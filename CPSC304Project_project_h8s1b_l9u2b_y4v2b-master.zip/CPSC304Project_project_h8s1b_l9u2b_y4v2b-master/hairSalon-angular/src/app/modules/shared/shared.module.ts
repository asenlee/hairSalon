import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalonCardComponent } from './components/salon-card/salon-card.component';
import {StyledModule} from '../styled/styled.module';
import {EmployeeModule} from '../employee/employee.module';
import { AlertDialogComponent } from './components/alert-dialog/alert-dialog.component';
import {FontAwesomeModule} from '@fortawesome/angular-fontawesome';



@NgModule({
  declarations: [SalonCardComponent, AlertDialogComponent],
  exports: [
    SalonCardComponent,
    AlertDialogComponent
  ],
  imports: [
    CommonModule,
    StyledModule,
    EmployeeModule,
    FontAwesomeModule
  ]
})
export class SharedModule { }
