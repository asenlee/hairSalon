import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {IconDefinition} from '@fortawesome/fontawesome-common-types';

export type AlertMessage = {
  icon?: IconDefinition,
  msg: string
  duration?: number
};

@Injectable({
  providedIn: 'root'
})
export class AlertDialogService {
  showAlert = new BehaviorSubject<AlertMessage>(null);

  constructor() {}

  showAlertDialog(alertMsg: AlertMessage): void {
    this.showAlert.next(alertMsg);
  }
}
