import {Component, Input, OnInit} from '@angular/core';
import {
  faCopyright,
  faDollarSign,
  faMapMarkerAlt,
  faSprayCan,
  faStore,
  faUsers, faUsersSlash
} from '@fortawesome/free-solid-svg-icons';
import {Salon} from '../../../../models/Salon';
import {Employee} from '../../../../models/Employee';
import {SalonService} from '../../../salon/services/salon.service';

@Component({
  selector: 'app-salon-card',
  templateUrl: './salon-card.component.html',
  styleUrls: ['./salon-card.component.scss']
})
export class SalonCardComponent implements OnInit {
  showEmployees: boolean;
  icons = {
    store: faStore,
    mapMarker: faMapMarkerAlt,
    users: faUsers,
    spray: faSprayCan,
    brand: faCopyright,
    dollar: faDollarSign,
    hide: faUsersSlash
  };

  @Input() salon: Salon;
  @Input() hideShowEmployeesBtn: boolean;


  constructor(private salonService: SalonService) { }

  ngOnInit(): void {
  }

  async getEmployees(): Promise<void> {
    await this.salonService.setEmployees(this.salon);
    this.showEmployees = true;
  }

  hideEmployees(): void {
    this.showEmployees = false;
  }

  async handleEmployeeClick(emp: Employee): Promise<void> {
    await this.salonService.setEmployeeSchedule(emp);
  }

  handleEmployeeDelete(emp: Employee): void {
    this.salon.employees.forEach((employee, index) => {
      if (employee.empID === emp.empID) {
        this.salon.employees.splice(index, 1);
        this.getEmployees();
      }
    });
  }
}
