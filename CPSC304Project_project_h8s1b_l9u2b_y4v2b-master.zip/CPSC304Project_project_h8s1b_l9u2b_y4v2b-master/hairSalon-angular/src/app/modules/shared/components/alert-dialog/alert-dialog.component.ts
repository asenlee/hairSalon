import { Component, OnInit } from '@angular/core';
import {faTimes} from '@fortawesome/free-solid-svg-icons';
import {AlertDialogService, AlertMessage} from '../../services/alert-dialog.service';
import {IconDefinition} from '@fortawesome/fontawesome-common-types';

@Component({
  selector: 'app-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialogComponent implements OnInit {
  cancelIcon = faTimes;
  msgIcon: IconDefinition;
  alertMsg: string;
  showAlert: boolean;
  alerts = new Map<string, AlertMessage>();

  constructor(private alertDialogService: AlertDialogService) { }

  ngOnInit(): void {
    this.alertDialogService.showAlert.subscribe(val => {
      if (val) {
        const date = new Date().toISOString();
        this.alerts.set(date, val);
        setTimeout(() => this.alerts.delete(date), val.duration || 3000);

        this.showAlert = true;
        this.msgIcon = val.icon;
        this.alertMsg = val.msg;

        setTimeout(() => {
          this.msgIcon = null;
          this.alertMsg = null;
          this.showAlert = false;
        }, val.duration || 3000);
      }
    });
  }

  dismissAlert(isoString?: string): void {
    this.showAlert = false;
    this.alerts.delete(isoString);
  }

  trackByFn(index, item): string {
    return index;
  }
}
