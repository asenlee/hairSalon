import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ButtonComponent} from './components/button/button.component';
import {CardComponent} from './components/card/card.component';
import {CustomerCardComponent} from './components/customer-card/customer-card.component';
import { BookingCardComponent } from './components/booking-card/booking-card.component';
import {FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import { IconWithInfoComponent } from './components/icon-with-info/icon-with-info.component';


@NgModule({
  declarations: [ButtonComponent, CardComponent, CustomerCardComponent, BookingCardComponent, IconWithInfoComponent,
  ],
  imports: [
    CommonModule,
    FontAwesomeModule,
  ],
  exports: [ButtonComponent, CardComponent, CustomerCardComponent, IconWithInfoComponent, BookingCardComponent]
})
export class StyledModule { }
