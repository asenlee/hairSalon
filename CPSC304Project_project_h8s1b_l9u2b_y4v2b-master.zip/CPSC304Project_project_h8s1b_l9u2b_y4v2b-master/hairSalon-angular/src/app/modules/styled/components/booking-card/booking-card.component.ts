import {Component, Input, OnInit} from '@angular/core';
import {
  faCalendarAlt,
  faClock,
  faCut,
  faMapMarkerAlt,
  faSpaceShuttle,
  faStore
} from "@fortawesome/free-solid-svg-icons";
import {Booking} from '../../../../models/Booking';

@Component({
  selector: 'app-booking-card',
  templateUrl: './booking-card.component.html',
  styleUrls: ['./booking-card.component.scss']
})
export class BookingCardComponent implements OnInit {
  storeIcon = faStore;
  calendarIcon = faCalendarAlt;
  clockIcon = faClock;
  mapIcon = faMapMarkerAlt;
  cutIcon = faCut;
  shuttleIcon = faSpaceShuttle;

  @Input() displayForCustomer: boolean;
  @Input() booking: Booking;

  constructor() { }

  ngOnInit(): void {
  }

}
