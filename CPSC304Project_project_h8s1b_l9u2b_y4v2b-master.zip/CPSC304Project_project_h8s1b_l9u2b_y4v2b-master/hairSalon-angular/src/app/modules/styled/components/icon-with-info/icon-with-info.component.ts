import {Component, Input, OnInit} from '@angular/core';
import {IconDefinition} from '@fortawesome/fontawesome-common-types';

@Component({
  selector: 'app-icon-with-info',
  templateUrl: './icon-with-info.component.html',
  styleUrls: ['./icon-with-info.component.scss']
})
export class IconWithInfoComponent implements OnInit {

  @Input() icon: IconDefinition;
  @Input() info: string | number;

  constructor() { }

  ngOnInit(): void {
  }

}
