import {Component, Input, OnInit} from '@angular/core';
import {Customer} from '../../../../models/Customer';
import {CustomerService} from '../../../customer/services/customer.service';
import {
  faCalendarMinus,
  faCalendarPlus,
  faEnvelope,
  faIdCard,
  faPhone,
  faUser
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-customer-card',
  templateUrl: './customer-card.component.html',
  styleUrls: ['./customer-card.component.scss']
})
export class CustomerCardComponent implements OnInit {
  showBookings: boolean;
  icons = {
    userIcon : faUser,
    mailIcon : faEnvelope,
    phoneIcon : faPhone,
    cardIcon : faIdCard,
    show: faCalendarPlus,
    hide: faCalendarMinus
  };
  @Input() customer: Customer = new Customer();

  constructor(private customerService: CustomerService) { }

  ngOnInit(): void {
  }

  async getBookings(): Promise<void> {
    this.customerService.setCustomer(this.customer);
    await this.customerService.getBookings();
    this.showBookings = true;
  }

  hideBookings(): void {
    this.showBookings = false;
  }
}
