import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SalonComponent} from './salon.component';
import {RouterModule, Routes} from '@angular/router';
import {SalonService} from './services/salon.service';
import {StyledModule} from '../styled/styled.module';
import {EmployeeModule} from '../employee/employee.module';
import {SharedModule} from "../shared/shared.module";

const routes: Routes = [
  {
    path: '',
    component: SalonComponent
  },
  {
    path: ':salonID',
    component: SalonComponent
  }
];

@NgModule({
  declarations: [SalonComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    StyledModule,
    EmployeeModule,
    SharedModule
  ],
  providers: [SalonService],
})
export class SalonModule { }
