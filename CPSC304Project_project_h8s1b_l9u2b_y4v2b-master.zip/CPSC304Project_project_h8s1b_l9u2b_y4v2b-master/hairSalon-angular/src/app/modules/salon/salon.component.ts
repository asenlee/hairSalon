import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {SalonService} from './services/salon.service';
import {Salon} from '../../models/Salon';

@Component({
  selector: 'app-admin',
  templateUrl: './salon.component.html',
  styleUrls: ['./salon.component.scss']
})
export class SalonComponent implements OnInit {
  salon: Salon;

  constructor(private route: ActivatedRoute, private salonService: SalonService) {
   this.salonService.setSalonFromDB(Number(this.route.snapshot.paramMap.get('salonID')))
     .then(salon => this.salon = salon);
  }

  ngOnInit(): void {
  }
}
