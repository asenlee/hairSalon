import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../../environments/environment';
import {Salon} from '../../../models/Salon';
import {Employee} from '../../../models/Employee';

@Injectable()
export class SalonService {
  url = environment.apiBaseURL + 'salon/';
  salon: Salon = new Salon();

  constructor(private http: HttpClient) {
  }

  async getAllSalons(): Promise<Salon[]> {
    const salonList = [];
    const list = await this.http.get(this.url + 'getAllSalons').toPromise() as [];
    list.forEach(s => salonList.push(new Salon().deserialize(s)));
    return salonList;
  }

  async setSalonFromDB(shopID: number): Promise<Salon> {
    const salonList = await this.http.post(this.url + 'getSalon', {shopID}).toPromise();
    this.salon = new Salon().deserialize(salonList[0]);
    return this.salon;
  }

  setSalon(salon: Salon): void {
    this.salon = salon;
  }

  async setEmployees(salon?: Salon): Promise<void> {
    salon = salon || this.salon;
    const empList = await this.http.post(this.url + 'getEmployees',
      {shopID: salon.shopID}).toPromise() as any[];
    salon.setEmployees(empList);
  }

  async setEmployeeSchedule(emp: Employee): Promise<void> {
    const scheduleList = await this.http.post(this.url + 'getEmployeeSchedule',
      {empID: emp.empID}).toPromise() as any[];
    emp.setSchedule(scheduleList);
  }

  getEmployees(shopID: number): Promise<any> {
    return this.http.post(this.url + 'getEmployees',
      {shopID}).toPromise();
  }

  getEmployeeSchedule(empID: number): Promise<any> {
    return this.http.post(this.url + 'getEmployeeSchedule',
      {empID}).toPromise();
  }

  async getEmployeeScheduleForDay(empID: number, day: string): Promise<any> {
    const res = await this.http.post(this.url + 'getEmployeeScheduleForDay',
      {empID, day }).toPromise();
    return res[0];
  }

  updateSchedule(dbData: object): Promise<any> {
    return this.http.post(this.url + 'updateEmployeeSchedule', dbData).toPromise();
  }

  deleteEmployee(empID: number): Promise<any> {
    return this.http.post(this.url + 'deleteEmployee', {empID}).toPromise();
  }
}
