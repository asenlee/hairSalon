import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {EmployeeCardComponent} from './components/employee-card/employee-card.component';
import {EditEmployeeScheduleComponent} from './components/edit-employee-schedule/edit-employee-schedule.component';
import {NewEmployeeService} from './services/new-employee.service';
import {StyledModule} from '../styled/styled.module';
import {NewEmployeeComponent} from './components/new-employee/new-employee.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';


@NgModule({
  declarations: [EmployeeCardComponent, EditEmployeeScheduleComponent, NewEmployeeComponent],
  imports: [
    CommonModule,
    StyledModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports: [EmployeeCardComponent, EditEmployeeScheduleComponent, NewEmployeeComponent],
  providers: [NewEmployeeService]
})
export class EmployeeModule { }
