import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {NewEmployee} from '../../../../models/NewEmployee';
import {NewEmployeeService} from '../../services/new-employee.service';
import {AlertDialogService} from "../../../shared/services/alert-dialog.service";
import {faCheckCircle} from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: 'app-new-employee',
  templateUrl: './new-employee.component.html',
  styleUrls: ['./new-employee.component.scss']
})
export class NewEmployeeComponent implements OnInit {
  newEmployee: NewEmployee;
  formGroup = new FormGroup({
    shopID: new FormControl('', Validators.required),
    empID: new FormControl(1, Validators.required),
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    position: new FormControl('', Validators.required),
  });

  constructor(private newEmpService: NewEmployeeService, private alertService: AlertDialogService) { }

  ngOnInit(): void {
    this.newEmployee = this.newEmpService.init();
    this.initForm();
  }

  initForm(): void {
    this.formGroup.valueChanges
      .subscribe(values => this.newEmpService.setValues(values));
  }

  handleSubmit(): void {
    this.newEmpService.createNew()
      .then(res => {
        console.log(res);
        const msg = `Record created for ${this.newEmployee.fullName}`;
        this.alertService.showAlertDialog({msg, icon: faCheckCircle});
      });
  }
}
