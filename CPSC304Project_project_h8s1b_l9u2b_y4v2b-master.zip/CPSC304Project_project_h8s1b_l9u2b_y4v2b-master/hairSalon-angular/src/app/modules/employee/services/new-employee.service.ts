import { Injectable } from '@angular/core';
import {environment} from '../../../../environments/environment';
import {SalonService} from '../../salon/services/salon.service';
import {NewEmployee} from '../../../models/NewEmployee';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewEmployeeService {
  url = environment.apiBaseURL + 'salon/';
  newEmployee: NewEmployee;

  constructor(private http: HttpClient, private salonService: SalonService) {}


  init(): NewEmployee {
    this.newEmployee = new NewEmployee();
    this.salonService.getAllSalons().then(salonList => this.newEmployee.salonList = salonList);
    return this.newEmployee;
  }

  setValues(values: object): void {
    Object.assign(this.newEmployee, values);
    this.newEmployee.setFullName();
  }

  createNew(): Promise<any> {
    return this.http.post(this.url + 'createNewEmployee',
      this.newEmployee.getDBObject()).toPromise();
  }
}
