import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import { AppComponent } from './app.component';
import {FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import {RouterModule} from '@angular/router';
import {SalonCardComponent} from './modules/shared/components/salon-card/salon-card.component';
import {SalonService} from './modules/salon/services/salon.service';
import {HttpClientModule} from '@angular/common/http';
import {Salon} from './models/Salon';
import {SharedModule} from './modules/shared/shared.module';
import {StyledModule} from './modules/styled/styled.module';
import {AdminComponent} from './modules/admin/admin.component';
import {AdminService} from './modules/admin/services/admin.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {AdminModule} from './modules/admin/admin.module';
import {Admin} from './models/Admin';

const salons = [
  {shopName: 'my salon', shopID: 1, street: '9830 100 avenue',
    city: 'Fort St John', postalCode: 'v1j1y5', province: 'BC'}
];
const hairProducts = [ { productID: 1, productName: 'Extra shine shampoo', brand: 'Dove', expensiveness: 4, }];

class MockService {
  admin = new Admin();

  init(): Admin {
    this.admin.setSalonList(salons);
    this.admin.setHairProducts(hairProducts);
    return this.admin;
  }

  getAllSalons(): any[] {
    return salons;
  }

  getAllHairProducts(): any[] {
    return hairProducts;
  }
}

describe('AppComponent', () => {
  let fixture: ComponentFixture<any>;
  let httpTestingContoller: HttpTestingController;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminModule, FontAwesomeModule, HttpClientModule, SharedModule, StyledModule, RouterModule.forRoot([]),
      HttpClientTestingModule],
      declarations: [
        AppComponent,
      ],
      providers: [SalonService, {provide: AdminService, useClass: MockService}]
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    httpTestingContoller = TestBed.inject(HttpTestingController);
  });

  it('admin view should display salons on initialization', waitForAsync(() => {
    fixture = TestBed.createComponent(AdminComponent);
    const adminComponent: AdminComponent = fixture.componentInstance;
    adminComponent.ngOnInit();
    fixture.detectChanges();
    fixture.whenStable()
      .then(() => {
        const compiled = fixture.nativeElement as HTMLElement;
        expect(adminComponent.currentView.type).toEqual(adminComponent.viewTypes.SALON);
        expect(compiled.querySelector('app-card[class="list-view zoom-in"]').textContent).toContain('my salon');
      });

    // const req1 = httpTestingContoller.expectOne('http://localhost:3000/salon/getAllCustomers').flush({});
    httpTestingContoller.match('http://localhost:3000/salon/getAllSalons').forEach(req => req.flush(salons));
  }));

  it('admin view should list hair products', waitForAsync(() => {
    fixture = TestBed.createComponent(AdminComponent);
    const adminComponent: AdminComponent = fixture.componentInstance;
    adminComponent.ngOnInit();
    adminComponent.currentView.type = 2;
    fixture.detectChanges();
    fixture.whenStable()
      .then(() => {
        const compiled = fixture.nativeElement as HTMLElement;
        expect(adminComponent.currentView.type).toEqual(adminComponent.viewTypes.HAIR_PRODUCTS);
        expect(compiled.querySelector('app-card[class="list-view zoom-in"]').textContent).toContain('Extra');
      });

    // const req1 = httpTestingContoller.expectOne('http://localhost:3000/salon/getAllCustomers').flush({});
    httpTestingContoller.match('http://localhost:3000/salon/getAllSalons').forEach(req => req.flush(salons));
  }));

  it('should display salon name', waitForAsync(() => {
    fixture = TestBed.createComponent(SalonCardComponent);
    const salonCardComponent: SalonCardComponent = fixture.componentInstance;
    salonCardComponent.salon = new Salon().deserialize(salons[0]);
    fixture.detectChanges();
    fixture.whenStable()
      .then(() => {
        const compiled = fixture.nativeElement;
        expect(compiled.querySelector('div[class="left"]').textContent).toContain('my salon');
      });
  }));
});
