# CPSC304Project_project_h8s1b_l9u2b_y4v2b

## To start Server:
>cd hairSalon-node
1. >npm i --save (this installs all the dependencies)
2. >npm run start


## To start Client:
>cd hairSalon-angular
1. >npm i --save
2. >npm run start
3. go to http://localhost:4200/

## MySQL Database
Database is hosted on cloud service provided by **ClearDB**.

Config Details (also available in hairSalon-node/dbConfig.js):
- **host**     : 'us-cdbr-east-03.cleardb.com' 
- **user**     : 'b90ecd9ebf51b3'
- **password** : '6684f871',
- **database** : 'heroku_2625166c71cfcd3'


