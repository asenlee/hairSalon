const connection = {
  host     : 'us-cdbr-east-03.cleardb.com',
  user     : 'b90ecd9ebf51b3',
  password : '6684f871',
  database : 'heroku_2625166c71cfcd3'
}

module.exports = {connection}
