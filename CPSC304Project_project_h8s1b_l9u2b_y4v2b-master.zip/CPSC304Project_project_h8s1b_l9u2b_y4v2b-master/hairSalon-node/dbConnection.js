
// start sql connection
const mysql = require('mysql2/promise');
const dbConfig = require("./dbConfig").connection;

const createConnection = () =>  mysql.createConnection(dbConfig)

const execQuery = async (query, values) => {
  const conn = await mysql.createConnection(dbConfig);
  const [rows, fields] = await conn.execute(query, values || []);
  conn.end();
  return rows;
}

module.exports = {createConnection, execQuery};
