const express = require('express');
const dbConnection = require("../dbConnection");
const {execQuery} = require("../dbConnection");
const router = express.Router();

/* GET all salons. */
router.get('/getAllSalons', async (req, res) => {
  res.send(await execQuery('SELECT * from hairsalon'));
});

/* GET all customers */
router.get('/getAllCustomers', async (req, res) => {
  res.send(await execQuery('SELECT * from customers'));
});

router.get('/getAllHairProducts', async (req, res) => {
  res.send(await execQuery('SELECT * from hairproducts h, productexpensiveness e where h.brand = e.brand'));
});

router.get('/getAllTables', async (req, res) => {
  res.send(await execQuery('select * from information_schema.TABLES where TABLE_SCHEMA = "heroku_2625166c71cfcd3"'));
});

router.get('/getSalonsSellAll', async (req, res) => {
  const query = 'select *\n' +
    'from hairsalon h, shopcity sc\n' +
    'where h.postalCode = sc.postalCode and not exists(select *\n' +
    '                                                  from hairproducts hp\n' +
    '                                                  where not exists(select *\n' +
    '                                                                   from sellsproducts s\n' +
    '                                                                   where s.shopID = h.shopID and hp.productID = s.productID))\n';
  res.send(await execQuery(query));
});

router.get('/getBrands', async (req, res) => {
  const query = 'select h.brand, count(*) as numProducts\n' +
    'from hairproducts h\n' +
    'group by h.brand';
  res.send(await execQuery(query));
});

router.get('/getPopularBrands', async (req, res) => {
  const query = 'select h.brand, count(*) as numProducts, sum(s.quantity) as totalQuantity\n' +
    'from hairproducts h, sellsproducts s\n' +
    'where h.productID = s.productID\n' +
    'group by h.brand\n' +
    'having sum(s.quantity) >= 400';
  res.send(await execQuery(query));
});

router.get('/getExpensiveBrands', async (req, res) => {
  const query = 'select h.brand, count(*) as numProducts, sum(s1.price) as totalPrice, avg(s1.price) as avgPrice\n' +
    'from hairproducts h, productexpensiveness p, sellsproducts s1\n' +
    'where h.brand = p.brand and h.productID = s1.productID\n' +
    'group by h.brand\n' +
    'having sum(s1.price) > (select avg(s2.price)\n' +
    '                       from sellsproducts s2)';
  res.send(await execQuery(query));
});

module.exports = router;
