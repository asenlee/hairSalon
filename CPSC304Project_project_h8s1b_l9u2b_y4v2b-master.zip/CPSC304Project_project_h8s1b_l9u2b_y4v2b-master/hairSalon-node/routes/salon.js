const express = require('express');
const {execQuery} = require("../dbConnection");
const router = express.Router();

router.get('/getAllSalons', async (req, res) => {
  res.send(await execQuery('SELECT * from hairsalon h, shopcity sc where h.postalCode = sc.postalCode'));
});

router.post('/getSalon', async (req, res) => {
  const {shopID} = req.body;
  res.send(await execQuery('SELECT * from hairsalon h, shopcity sc where h.shopID = ? and h.postalCode = sc.postalCode',
    [shopID]));
});

router.post('/getEmployees', async (req, res) => {
  const results = await execQuery('SELECT * from hairsalon h, employees e where h.shopID = ? and e.shopID = h.shopID',
    [req.body.shopID])
  res.send(results)
});

router.post('/getEmployeeScheduleForDay', async (req, res) => {
  const results = await execQuery('SELECT s.day, s.shiftStart, s.end from employees e, schedule s where e.empID = ? and s.day = ? and e.empID = s.empID',
    [req.body.empID, req.body.day])
  res.send(results)
});

router.post('/getEmployeeSchedule', async (req, res) => {
  const results = await execQuery('SELECT s.day, s.shiftStart, s.end from employees e, schedule s where e.empID = ? and e.empID = s.empID',
    [req.body.empID])
  res.send(results)
});

router.post('/getAllEmployeeSchedule', async (req, res) => {
  const results = await execQuery('SELECT * from employees e, schedule s where e.shopID = ? and e.empID = s.empID',
    [req.body.shopID])
  console.log(results)
  res.send(results)
});

router.post('/createNewEmployee', async (req, res) => {
  const {shopID, firstName, lastName, position, empID} = req.body;
  const query = 'insert into employees values(?,?,?,?,?)'
  const results = await execQuery(query,[empID, firstName, lastName, position, shopID])
  console.log(results)
  res.send(results)
});

router.post('/deleteEmployee', async (req, res) => {
  const {empID} = req.body;
  const query = 'delete from employees where empID = ?'
  const results = await execQuery(query,[empID])
  console.log(results)
  res.send(results)
});

router.post('/updateEmployeeSchedule', async (req, res, next) => {
  const {empID, scheduleList} = req.body;
  console.log(req.body)
  const promises = [];
  for (const s of scheduleList) {
    const {shiftStart, end, day, deleteDay, update} = s;
    if (deleteDay)
      promises.push(execQuery('delete from schedule where empID = ? and day = ?',
        [empID, day]))
    else if (update)
      promises.push(execQuery('update schedule sc set shiftStart = ?, end = ? where empID = ? and day = ?',
        [shiftStart, end, empID, day]))
    else // new day schedule
      promises.push(execQuery('insert into schedule values(?, ?, ?, ?)',
        [empID, day, shiftStart, end]))

  }
  Promise.all(promises)
    .then(results => res.send(results))
    .catch(next)
});

module.exports = router;
