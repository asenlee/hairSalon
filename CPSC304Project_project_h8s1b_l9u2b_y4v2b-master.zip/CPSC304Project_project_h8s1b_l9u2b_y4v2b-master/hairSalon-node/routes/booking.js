const express = require('express');
const execQuery = require('../dbConnection').execQuery
const router = express.Router();


router.post('/createNew',   function(req, res, next) {
  let  {empID, date, day, startTime, endTime, notes, phoneNumber} = req.body;
  notes = notes || null;

  Promise.resolve(execQuery('insert into bookings values(?, ?, ?, ?, ?, ?, ?)',
    [phoneNumber, empID, date, day, startTime, endTime, notes]))
    .then(result => {
      console.log(result);
      res.send(result)
    })
    .catch(e => {
      console.log(e)
      if (e.errno === 1062)
        res.status(500).send({msg: 'Booking Already Exists', reason: 'I dont know'})
      else
        res.status(500).send('Booking Failed')
    })

  // try {
  //   res.send(await execQuery('insert into bookings values(?, ?, ?, ?, ?, ?, ?)',
  //     [phoneNumber, empID, date, day, startTime, endTime, notes]));
  // } catch (e) {
  //   // next(e)
  //   console.log(e)
  //   res.status(500).send('Booking Already Exists')
  // }
});


module.exports = router;
