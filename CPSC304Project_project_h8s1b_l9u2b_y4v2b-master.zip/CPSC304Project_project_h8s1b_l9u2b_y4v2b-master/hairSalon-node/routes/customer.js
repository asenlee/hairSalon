const express = require('express');
const execQuery = require('../dbConnection').execQuery
const router = express.Router();


router.post('/getCustomer',  async function(req, res) {
  const results = await execQuery('SELECT * from customers where phoneNumber = ?',
    [req.body.phoneNumber])
  res.send(results)
});

router.post('/getBookings',  async function(req, res) {
  const query = 'SELECT e.firstName as e_firstName, e.lastName as e_lastName, h.shopID, shopNumber, h.postalCode, shopName, street,\n' +
    '       city, province, e.empID, e.position, b.phoneNumber, date, day, startTime, endTime, notes\n' +
    'from bookings b, employees e, hairsalon h, shopcity sc\n' +
    'where sc.postalCode = h.postalCode and b.empID = e.empID and \n' +
    '      h.shopID = e.shopID and phoneNumber = ?'
  const results = await execQuery(query, [req.body.phoneNumber])
  res.send(results)
});

module.exports = router;
